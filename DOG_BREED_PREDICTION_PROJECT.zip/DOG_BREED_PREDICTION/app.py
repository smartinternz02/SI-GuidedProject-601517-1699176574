import numpy as np
import os
from keras.models import load_model
from keras.utils import load_img,img_to_array
from PIL import Image
from flask import Flask,request,render_template

app=Flask(__name__)
model=load_model("dogBreed.h5",compile=False)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/predict')
def predict():
    return render_template("predict.html")

@app.route('/output',methods=['GET','POST'])
def output():
    if request.method == 'POST':     
      f=request.files['file']
      basepath=os.path.dirname(__file__)
      filepath=os.path.join(basepath,'uploads',f.filename)
      f.save(filepath)
      img=load_img(filepath,target_size=(224,224)) 
      x=img_to_array(img)
      x=np.expand_dims(x,axis=0)
      pred=np.argmax(model.predict(x),axis=1)
      index = ['Affenpinscher','Beagle','Appenzeller','Basset','Bluetick','Boxer','Cairn',
               'Doberman','German Shepherd','Golden Retriever','Kelpie','Komondor','Leonberg',
               'Mexican_Hairless','Pug','Redbone','Shih-tzu','Toy Poodle','Vizsla','Whippe']
      breed_prediction=index[pred[0]]
      return render_template('output.html',breed=breed_prediction)
if __name__ == '__main__':
    app.run(debug=False,threaded=False)
